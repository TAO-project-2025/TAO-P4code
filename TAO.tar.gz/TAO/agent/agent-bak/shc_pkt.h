#pragma once

#include <memory>
#include "spdlog/spdlog.h"

namespace shc {

extern int sfc_pkt_thread(void);

} // namespace shc
