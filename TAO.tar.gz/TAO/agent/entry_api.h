#ifndef SHC_ENTRY_API_H
#define SHC_ENTRY_API_H

#include <stdio.h>
#include <stdlib.h>

extern int 
shc_swTohw_rule(uint32_t vni,uint32_t ip_src_addr,uint32_t ip_dst_addr,int flag_of_add_del);

#endif
