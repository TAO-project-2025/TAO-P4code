// #include "base_table.hpp"

// using namespace std;

// namespace shc {


// void BaseTable::tableMutexLock() { 

// }
//   public:
//     // BaseTable() {};
//     tableMutexLock();
//     tableMutexUnlock();

// }