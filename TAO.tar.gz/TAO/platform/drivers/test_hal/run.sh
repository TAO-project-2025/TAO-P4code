sudo LD_LIBRAYR_PATH=${SDE}/install/lib/ ./driver_test --install-dir=$SDE_INSTALL --conf-file=${SDE}/install/share/p4/targets/tofino/shc_real_time_sketch.conf --bfshell
